package controller;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import model.Transact;
import model.TransactionEntity;
import service.TransactionEJB;

@ManagedBean(name="transactcontroller")
@SessionScoped
public class TransactController {

	@EJB
	TransactionEJB transactionservice;
	
	

	@ManagedProperty(value="#{transact}")
	private Transact transact;
	
	public void addNewTransaction()
	{
		TransactionEntity transactionEntity = null;
		transactionservice.addNewTransaction(transactionEntity);
	}
	
	
	public Transact getTransact() {
		return transact;
	}

	public void setTransact(Transact transact) {
		this.transact = transact; 
	}

	
	
	
}
