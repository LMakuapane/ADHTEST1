package model;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name= "transact")
@SessionScoped
public class Transact {
	
	private String Name;
	private String SourcePassport;
	private String DestinationPassport;
	private String DestinationBank;
	private String DestationCountry;
	private String AccountNumber;
	private Float Amount;
	//private int TransactionCode;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getSourcePassport() {
		return SourcePassport;
	}
	public void setSourcePassport(String sourcePassport) {
		SourcePassport = sourcePassport;
	}
	public String getDestinationPassport() {
		return DestinationPassport;
	}
	public void setDestinationPassport(String destinationPassport) {
		DestinationPassport = destinationPassport;
	}
	public String getDestinationBank() {
		return DestinationBank;
	}
	public void setDestinationBank(String destinationBank) {
		DestinationBank = destinationBank;
	}
	public String getDestationCountry() {
		return DestationCountry;
	}
	public void setDestationCountry(String destationCountry) {
		DestationCountry = destationCountry;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public Float getAmount() {
		return Amount;
	}
	public void setAmount(Float amount) {
		Amount = amount;
	}
	/*
	 * public int getTransactionCode() { return TransactionCode; } public void
	 * setTransactionCode(int transactionCode) { TransactionCode = transactionCode;
	 * }
	 */
	
	public TransactionEntity getEntity()
	{
		TransactionEntity transactionentity= new TransactionEntity();
		transactionentity.setName(Name);
		transactionentity.setSourcePassport(SourcePassport);
		transactionentity.setDestinationPassport(DestinationPassport);
		transactionentity.setDestinationBank(DestinationBank);
		transactionentity.setDestationCountry(DestationCountry);
		transactionentity.setAccountNumber(AccountNumber);
		transactionentity.setAmount(Amount);
		
		return transactionentity;
	}
	}
	
	
		
	

